import { Injectable } from '@angular/core';
import { StorageService } from './storage.service';


@Injectable({ providedIn: 'root' })
export class BonusService {
  constructor(private storageService: StorageService) {
    console.log('BonusService initialized');
    this.init();
  }

  init() {
    // Nach 1 Minute → Klicks x2
    // TODO: Bonus-Logik in StorageService integrieren
    // Nach 2 Minuten → Klicks x4
  }
}