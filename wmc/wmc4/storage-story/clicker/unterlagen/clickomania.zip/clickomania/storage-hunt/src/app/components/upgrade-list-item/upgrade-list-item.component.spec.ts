import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpgradeListItemComponent } from './upgrade-list-item.component';

describe('UpgradeListItemComponent', () => {
  let component: UpgradeListItemComponent;
  let fixture: ComponentFixture<UpgradeListItemComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UpgradeListItemComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UpgradeListItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
