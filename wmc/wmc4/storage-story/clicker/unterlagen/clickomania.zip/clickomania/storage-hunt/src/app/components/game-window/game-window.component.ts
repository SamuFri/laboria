import { Component } from '@angular/core';
import { ClickerComponent } from '../clicker/clicker.component';
import { PowerBonusComponent } from '../power-bonus/power-bonus.component';

@Component({
  selector: 'app-game-window',
  standalone: true,
  imports: [ClickerComponent, PowerBonusComponent],
  templateUrl: './game-window.component.html',
  styleUrl: './game-window.component.css'
})
export class GameWindowComponent {

}
