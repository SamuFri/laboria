import { Component, OnInit } from '@angular/core';
import { StorageService } from '../../core/storage.service';

@Component({
  selector: 'app-power-bonus',
  standalone: true,
  imports: [],
  templateUrl: './power-bonus.component.html',
  styleUrl: './power-bonus.component.css'
})
export class PowerBonusComponent  {


  constructor(private storage: StorageService) {}

}
