import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { NavigationComponent } from './components/shell/navigation/navigation.component';
import { GameWindowComponent } from './components/game-window/game-window.component';
import { BonusService } from './core/bonus.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, NavigationComponent, GameWindowComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'storage-hunt';
  constructor(private bonusService: BonusService) {
  }
}
