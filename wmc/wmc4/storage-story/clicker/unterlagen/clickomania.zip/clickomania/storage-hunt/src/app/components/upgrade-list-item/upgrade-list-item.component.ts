import { Component, Input } from '@angular/core';
import { UpgradeItem } from '../../model/upgrade-item';

@Component({
  selector: 'app-upgrade-list-item',
  standalone: true,
  imports: [],
  templateUrl: './upgrade-list-item.component.html',
  styleUrl: './upgrade-list-item.component.css'
})
export class UpgradeListItemComponent {
  @Input() upgrade: UpgradeItem | null = null;
}
