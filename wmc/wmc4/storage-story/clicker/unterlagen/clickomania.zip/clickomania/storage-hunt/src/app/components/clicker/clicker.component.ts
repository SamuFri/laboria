import { Component } from '@angular/core';
import { StorageService } from '../../core/storage.service';

@Component({
  selector: 'app-clicker',
  standalone: true,
  imports: [],
  templateUrl: './clicker.component.html',
  styleUrl: './clicker.component.css'
})
export class ClickerComponent {
  clicks = 0;

  constructor(private storageService: StorageService) {
    
  }

  click() {

  }
}
