import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StorageService {
  // TODO: LocalStorage und SessionStorage Keys
 

  // LocalStorage
  getClicks(): number {
  }

  setClicks(value: number) {
  }

  
  // SessionStorage Bonus
  getMultiplier(): number {
  }

  setMultiplier(value: number) {
  }
}
