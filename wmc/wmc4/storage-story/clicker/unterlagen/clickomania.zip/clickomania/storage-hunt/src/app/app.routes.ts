import { Routes } from '@angular/router';
import { GameWindowComponent } from './components/game-window/game-window.component';
import { UpgradeListComponent } from './components/upgrade-list/upgrade-list.component';

export const routes: Routes = [
    {
        path: 'game',
        component: GameWindowComponent, // Standalone
    },
    {
        path: 'upgrades',
        component: UpgradeListComponent, // Standalone
    },
    { path: '', redirectTo: 'game', pathMatch: 'full' }
];