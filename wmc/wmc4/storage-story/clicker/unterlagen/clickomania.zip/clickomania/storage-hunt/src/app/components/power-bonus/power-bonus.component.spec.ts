import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PowerBonusComponent } from './power-bonus.component';

describe('PowerBonusComponent', () => {
  let component: PowerBonusComponent;
  let fixture: ComponentFixture<PowerBonusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PowerBonusComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PowerBonusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
