export interface UpgradeItem {
    id: number;
    name: string;
    description: string;
    cost: number;
    multiplier: number;
    isActive: boolean;
}