import { Component, OnInit } from '@angular/core';
import { UpgradeDbService } from '../../core/upgrade-db.service';
import { UpgradeListItemComponent } from '../upgrade-list-item/upgrade-list-item.component';
import { UpgradeItem } from '../../model/upgrade-item';

@Component({
  selector: 'app-upgrade-list',
  standalone: true,
  imports: [UpgradeListItemComponent],
  templateUrl: './upgrade-list.component.html',
  styleUrl: './upgrade-list.component.css'
})
export class UpgradeListComponent implements OnInit {
  upgrades: UpgradeItem[] = [];

  constructor(private db: UpgradeDbService) { }

  async ngOnInit() {
  }
}
