import { Injectable } from '@angular/core';
import { openDB, DBSchema, IDBPDatabase } from 'idb';
import { UpgradeItem } from '../model/upgrade-item';

interface ClickerDB extends DBSchema {
  upgrades: {
    key: number;
    value: UpgradeItem;
  };
}
@Injectable({
  providedIn: 'root'
})
export class UpgradeDbService {
}