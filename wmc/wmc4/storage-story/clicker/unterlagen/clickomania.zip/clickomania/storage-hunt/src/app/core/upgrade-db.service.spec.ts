import { TestBed } from '@angular/core/testing';

import { UpgradeDbService } from './upgrade-db.service';

describe('UpgradeDbService', () => {
  let service: UpgradeDbService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UpgradeDbService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
